package edu.wwu.csci412.a2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.content.Intent;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String MA = "MainActivity";
    public static Info info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        info = new Info(this);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onStart(){
        super.onStart();
        updateView();
    }

    @Override
    public void onResume(){
        super.onResume();
        updateView();
    }

    public void onClick(View view){
        updateView();
    }

    public void updateView(){
        //get the images
        View pizza = findViewById(R.id.pizzaImage);
        View applebees = findViewById(R.id.applebeesImage);
        View olivegarden = findViewById(R.id.olivegardenImage);
        //get the buttons
        RadioButton pizzaButton = findViewById(R.id.pizza);
        RadioButton applebeesButton = findViewById(R.id.applebees);
        RadioButton olivegardenButton = findViewById(R.id.olivegarden);
        //get the reviews
        TextView pizzaText = findViewById(R.id.pizzaReview);
        pizzaText.setText(info.getPizzaReview());
        TextView applebeesText = findViewById(R.id.applebeesReview);
        applebeesText.setText(info.getApplebeesReview());
        TextView olivegardenText = findViewById(R.id.olivegardenReview);
        olivegardenText.setText(info.getOlivegardenReview());
        //get the ratings
        RatingBar pizzaRating = findViewById(R.id.pizzaRating);
        pizzaRating.setRating(info.getPizzaRating());
        RatingBar applebeesRating = findViewById(R.id.applebeesRating);
        applebeesRating.setRating(info.getApplebeesRating());
        RatingBar olivegardenRating = findViewById(R.id.olivegardenRating);
        olivegardenRating.setRating(info.getOlivegardenRating());
        // Check which radio button was clicked
        int button = 1;
        //if Wood Fire Pizza was clicked
        if(pizzaButton.isChecked()) {
            button = 1;
            pizza.setAlpha(1);
            applebees.setAlpha(0);
            olivegarden.setAlpha(0);
            pizzaText.setAlpha(1);
            applebeesText.setAlpha(0);
            olivegardenText.setAlpha(0);
            pizzaRating.setAlpha(1);
            applebeesRating.setAlpha(0);
            olivegardenRating.setAlpha(0);
        }
        //if Applebee's was clicked
        else if(applebeesButton.isChecked()) {
            button = 2;
            pizza.setAlpha(0);
            applebees.setAlpha(1);
            olivegarden.setAlpha(0);
            pizzaText.setAlpha(0);
            applebeesText.setAlpha(1);
            olivegardenText.setAlpha(0);
            pizzaRating.setAlpha(0);
            applebeesRating.setAlpha(1);
            olivegardenRating.setAlpha(0);
        }
        //if Olive Garden was clicked
        else if(olivegardenButton.isChecked()) {
            button = 3;
            pizza.setAlpha(0);
            applebees.setAlpha(0);
            olivegarden.setAlpha(1);
            pizzaText.setAlpha(0);
            applebeesText.setAlpha(0);
            olivegardenText.setAlpha(1);
            pizzaRating.setAlpha(0);
            applebeesRating.setAlpha(0);
            olivegardenRating.setAlpha(1);
        }
        info.setButton(button);
    }

    //this is the implementation of the "modify" button
    public void modify(View v){
        Intent myIntent = new Intent(this, Modify.class);
        this.startActivity(myIntent);
    }

}
