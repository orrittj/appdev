package edu.wwu.csci412.a2;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

//This class will hold the info so that the two activities can communicate
public class Info {
    private static final String PIZZA_REVIEW = "pizzaReview";
    private static final String APPLEBEES_REVIEW = "applebeesReview";
    private static final String OLIVEGARDEN_REVIEW = "olivegardenReview";
    private static final String PIZZA_RATING = "pizzaRating";
    private static final String APPLEBEES_RATING = "applebeesRating";
    private static final String OLIVEGARDEN_RATING = "olivegardenRating";
    private static final String BUTTON = "button";
    private String pizzaReview;
    private float pizzaRating;
    private String applebeesReview;
    private float applebeesRating;
    private String olivegardenReview;
    private float olivegardenRating;
    private int button;

    //this establishes the default data for each of the restaurants
    public Info(Context context){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        setPizzaReview(pref.getString(PIZZA_REVIEW, "default pizza"));
        setPizzaRating(pref.getFloat(PIZZA_RATING, 4));
        setApplebeesReview(pref.getString(APPLEBEES_REVIEW, "default applebees"));
        setApplebeesRating(pref.getFloat(APPLEBEES_RATING, 2));
        setOlivegardenReview(pref.getString(OLIVEGARDEN_REVIEW, "default olivegarden"));
        setOlivegardenRating(pref.getFloat(OLIVEGARDEN_RATING, 4));
        setButton(pref.getInt(BUTTON, 1));
    }
    //save preferences
    public void setPreferences(Context context){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        //save
        //save reviews
        editor.putString(PIZZA_REVIEW, getPizzaReview());
        editor.putString(APPLEBEES_REVIEW, getApplebeesReview());
        editor.putString(OLIVEGARDEN_REVIEW, getOlivegardenReview());
        //save ratings
        editor.putFloat(PIZZA_RATING, getPizzaRating());
        editor.putFloat(APPLEBEES_RATING, getApplebeesRating());
        editor.putFloat(OLIVEGARDEN_RATING, getOlivegardenRating());
        //save button
        editor.putInt(BUTTON, getButton());
        editor.commit();
    }

    //SETTER METHODS//
    //These will set the string values
    public void setPizzaReview(String s){
        pizzaReview = s;
    }
    public void setApplebeesReview(String s){
        applebeesReview = s;
    }
    public void setOlivegardenReview(String s){
        olivegardenReview = s;
    }

    //These will set the ratings
    public void setPizzaRating(float x){
        pizzaRating = x;
    }
    public void setApplebeesRating(float x) {
        applebeesRating = x;
    }
    public void setOlivegardenRating(float x) {
        olivegardenRating = x;
    }

    //set which button is pushed
    public void setButton(int x){
        button = x;
    }
    //GETTER METHODS//

    //This will return which radio button is active
    //1 = pizza, 2 = applebees, 3 = olivegarden
    public int getButton(){
        return button;
    }

    //These will return to MainActivity what the values of the strings are
    public String getPizzaReview(){
        return pizzaReview;
    }
    public String getApplebeesReview(){
        return applebeesReview;
    }
    public String getOlivegardenReview(){
        return olivegardenReview;
    }

    //These will return to MainActivity what the ratings are
    public float getPizzaRating(){
        return pizzaRating;
    }
    public float getApplebeesRating(){
        return applebeesRating;
    }
    public float getOlivegardenRating(){
        return olivegardenRating;
    }

}
