package edu.wwu.csci412.a2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Modify extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modify_data);
        display();
    }

    //display the info upon first getting to this page
    public void display(){
        Info info = MainActivity.info;
        //get the images
        View pizza = findViewById(R.id.pizzaImage);
        View applebees = findViewById(R.id.applebeesImage);
        View olivegarden = findViewById(R.id.olivegardenImage);
        //get the review
        EditText text = findViewById(R.id.reviewEdit);

        if(info.getButton() == 1){
            pizza.setAlpha(1);
            applebees.setAlpha(0);
            olivegarden.setAlpha(0);
            text.setText(info.getPizzaReview());
        }
        else if(info.getButton() == 2){
            pizza.setAlpha(0);
            applebees.setAlpha(1);
            olivegarden.setAlpha(0);
            text.setText(info.getApplebeesReview());
        }
        else{
            pizza.setAlpha(0);
            applebees.setAlpha(0);
            olivegarden.setAlpha(1);
            text.setText(info.getOlivegardenReview());
        }
    }

    //this is the implementation of the "modify" button
    public void modify(View v){
        Info info = MainActivity.info;
        //get the review
        EditText text = findViewById(R.id.reviewEdit);
        //get the rating
        EditText rating = findViewById(R.id.ratingEdit);

        //change the info depending on what restaurant we are looking at
        //change pizza
        if(info.getButton() == 1){
            info.setPizzaReview(text.getText().toString());
            info.setPizzaRating(Integer.parseInt(rating.getText().toString()));
        }
        //change applebees
        else if(info.getButton() == 2){
            text.setText(info.getApplebeesReview());
            info.setApplebeesReview(text.getText().toString());
            info.setApplebeesRating(Integer.parseInt(rating.getText().toString()));
        }
        //change olivegarden
        else{
            text.setText(info.getOlivegardenReview());
            info.setOlivegardenReview(text.getText().toString());
            info.setOlivegardenRating(Integer.parseInt(rating.getText().toString()));
        }
        //save preferences
        info.setPreferences(this);
        //return to main
        this.finish();
    }
}
